def calcular_heuristicos(data):
    
    print("Proceso de calcular heuristicos")

    return data
