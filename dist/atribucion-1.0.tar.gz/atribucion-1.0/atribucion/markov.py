def calcular_markov(data):
    
    print("Proceso de calcular Markov")

    return data

def formatear_markov(data, parametros):

    for k,v in parametros.items():
        print("Parametros: ",k,v)
    
    print("Proceso de formatear Markov")
    
    return data
